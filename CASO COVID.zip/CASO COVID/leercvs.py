#programa que lee CVS

#libreria para acceder a archivos CVS

import csv
#el programa usa snake notation.

#with genera un bloque de codigo con referencia.
with open('AnalisisCOVID.csv') as archivo_csv:
    #habilito un objeto que me permitira leer de forma secuencial el contenido del archivo.
    lector_csv = csv.reader(archivo_csv, delimiter='|')
    #inicia el contador de lineas.
    contador_lineas = 0
    #voy a leer secuencialmente el archivo usando el flujo de datos 
    for linea_datos in lector_csv:
        #si el contador vale 0 entonces nos encontramos en la primera linea del archivo.
        if contador_lineas == 0:
            #Lista de datos contenidos en linea separado por coma
            print(f'Los nombres de la columna son {", ".join(linea_datos)}')
        else:
            #mostrar dato por dato los contenidos en linea.
            print(f'\tFECHA: {linea_datos[0]}.')
            print(f'\tNUEVOS CONTAGIOS: {linea_datos[1]}.')
            print(f'\tNUEVOS FALLECIMIENTOS: {linea_datos[2]}.')
            print(f'\tPAIS: {linea_datos[3]}.')
            print(f'\t-----------------------')

        contador_lineas += 1

    print(f'Procesadas {contador_lineas} lineas.')