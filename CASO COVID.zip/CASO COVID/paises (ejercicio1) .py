#datos tipo fecha
import datetime 

class Pais:
      # constructor , metodo que se encarga de generar un objeto.
      # parametrizado, esta clase tienen 5 propiedades las cuales estan entrew ().
      # self no es una propiedad es referencia hacia el mismo objeto.
      def __init__(self, NombreIng , NombreEsp , Fallecidos , Contagiados, PDC):
            # NombreIng: nombre pais en ingles (str).
            # NombreEsp: nombre pais en español (str).
            # Fallecidos: Total de fallecidos rgistrados (int).
            # PDC: primer dia de contagio (datetime) .
            # Contagiados: Total de contagiados registrados en el pais (int). 
            self.NombreIng = NombreIng
            self.NombreEsp = NombreEsp
            self.Fallecidos = Fallecidos
            self.Contagiados = Contagiados
            self.PDC = PDC

class  Incidente:
      def __init__(self,Fecha,Pais,NContangios,NFallecidos):
            # fecha: fecha de los datos (datetime)
            # pais: nombre del pais que reporta los datos (str)
            # NContagios: nuevos contagios en pais y fecha (int)
            # NFallecidos: nuevos fallecimientos en pais y fecha (int)
            self.Fecha = Fecha
            self.Pais = Pais
            self.NContangios = NContangios
            self.NFallecidos = NFallecidos

#instanciar clase pais
PaisMX = Pais(str("Mexico"), str("Mexico"), int(1000), int(5000), datetime.datetime(2020, 5, 18))
PaisCh = Pais(str("China"), str("China"), int(2000), int(6000), datetime.datetime(2020, 5, 10))
PaisEu = Pais(str("EU"), str("EU"), int(3000), int(4000), datetime.datetime(2020, 5, 17))
PaisBr = Pais(str("Brasil"), str("Brasil"), int(4000), int(6000), datetime.datetime(2020, 5, 16))
PaisJa = Pais(str("Japon"), str("Japon"), int(5000), int(7000), datetime.datetime(2020, 5, 19))

#instanciar la clase incidente
incidenteAyer = Incidente(datetime.datetime(2020, 5, 17), str("Mexico"), int(1500), int(18) )
IncidenteHoy = Incidente(datetime.datetime.now(), str("Mexico"), int(1400), int(12) )

#lista paises
lista_pais = []

#elementos con .append
lista_pais.append(PaisMX)
lista_pais.append(PaisCh)
lista_pais.append(PaisEu)
lista_pais.append(PaisBr)
lista_pais.append(PaisJa)

#creacion  de una lista , la lista esta vacia.
mi_lista = []

#creacion de una lista
mi_lista.append(incidenteAyer)
mi_lista.append(IncidenteHoy)

#mostrar elementos de una lista
print(len(mi_lista)) 

#barrido secuencial de la lista
for elemento in mi_lista:
  print(elemento.Fecha)

#ELEMENTOS LISTAS FECHA
print(len(lista_pais))

#BARRIDO LISTAS PAIS
for elemento in lista_pais:
    print(elemento.NombreEsp)
