#programa que lee CVS

#libreria para acceder a archivos CVS

import csv

#libreria datetime
import datetime
#clase para almacenar incidentes
class incidente:
      # constructor , metodo que se encarga de generar un objeto.
      # parametrizado, esta clase tienen 5 propiedades las cuales estan entrew ().
      # self no es una propiedad es referencia hacia el mismo objeto.
      def __init__(self, FECHA , CASOS , MUERTES , PAIS):
            # NombreIng: nombre pais en ingles (str).
            # NombreEsp: nombre pais en español (str).
            # Fallecidos: Total de fallecidos rgistrados (int).
            # PDC: primer dia de contagio (datetime) .
            # Contagiados: Total de contagiados registrados en el pais (int). 
            self.FECHA = FECHA 
            self.CASOS = CASOS
            self.MUERTES = MUERTES
            self.PAIS= PAIS
#LECTURA SECUENCIAL DEL ARCHIVO 
with open('AnalisisCOVID.csv') as archivo_csv:
    lector_csv = csv.reader(archivo_csv, delimiter='|')
    contador_lineas = 0
    #creacion lista vacia
    lista_incidentes = []
    #lista secuencial 
    for linea_datos in lector_csv:
        if contador_lineas == 0:
            #si es la primera linea, muestro los nombres de campo y no guardo nada en la lista.
            print(f'Los nombres de la columna son {", ".join(linea_datos)}')
        else:
            #si son datos (linea 1 y posteriores)
            #genero una instancia de la clase incidente y se la proporciono al constructor los valores leidos del archivo.
            objeto_temporal = incidente({linea_datos[0]},{linea_datos[1]},{linea_datos[2]},{linea_datos[3]})
            lista_incidentes.append(objeto_temporal)

        contador_lineas += 1

    print(f'Procesadas {len(lista_incidentes)} lineas.')
