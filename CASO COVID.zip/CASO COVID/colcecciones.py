#datos tipo fecha
import datetime 

class  Incidente:
      def __init__(self,Fecha,Pais,NContangios,NFallecidos):
            # fecha: fecha de los datos (datetime)
            # pais: nombre del pais que reporta los datos (str)
            # NContagios: nuevos contagios en pais y fecha (int)
            # NFallecidos: nuevos fallecimientos en pais y fecha (int)
            self.Fecha = Fecha
            self.Pais = Pais
            self.NContangios = NContangios
            self.NFallecidos = NFallecidos

#instanciar la clase incidente
incidenteAyer = Incidente(datetime.datetime(2020, 5, 17), str("Mexico"), int(1500), int(18) )
IncidenteHoy = Incidente(datetime.datetime.now(), str("Mexico"), int(1400), int(12) )

#creacion  de una lista , la lista esta vacia.
mi_lista = []

#creacion de una lista
mi_lista.append(incidenteAyer)
mi_lista.append(IncidenteHoy)

#mostrar elementos de una lista
print(len(mi_lista)) 

#barrido secuencial de la lista
for elemento in mi_lista:
  print(elemento.Fecha)

