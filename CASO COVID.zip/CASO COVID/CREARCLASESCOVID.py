#datos tipo fecha
import datetime 
# declaramos las clases
# nombre utiliza pascal casing
class Pais:
      # constructor , metodo que se encarga de generar un objeto.
      # parametrizado, esta clase tienen 5 propiedades las cuales estan entrew ().
      # self no es una propiedad es referencia hacia el mismo objeto.
      def __init__(self, NombreIng , NombreEsp , Fallecidos , Contagiados, PDC):
            # NombreIng: nombre pais en ingles (str).
            # NombreEsp: nombre pais en español (str).
            # Fallecidos: Total de fallecidos rgistrados (int).
            # PDC: primer dia de contagio (datetime) .
            # Contagiados: Total de contagiados registrados en el pais (int). 
            self.NombreIng = NombreIng
            self.NombreEsp = NombreEsp
            self.Fallecidos = Fallecidos
            self.Contagiados = Contagiados
            self.PDC = PDC

class  Incidente:
      def __init__(self,Pais,Fecha,NContangios,NFallecidos):
            # fecha: fecha de los datos (datetime)
            # pais: nombre del pais que reporta los datos (str)
            # NContagios: nuevos contagios en pais y fecha (int)
            # NFallecidos: nuevos fallecimientos en pais y fecha (int)
            self.Fecha = Fecha
            self.Pais = Pais
            self.NContangios = NContangios
            self.NFallecidos = NFallecidos

# probar el funcionamiento de nuestras clases.
# instanciar la clase pais (creamos un objeto de tipo pais).
miPais = Pais(str("Mexico"),str("México"),int(1000),int(5000), datetime.datetime(2020, 5, 18) )
print(miPais.PDC)

#instanciar la clase incidente
incidenteAyer = Incidente(datetime.datetime(2020, 5, 17), str("Mexico"), int(1500), int(18) )
IncidenteHoy = Incidente(datetime.datetime.now(), str("Mexico"), int(1400), int(12) )
print(incidenteAyer.Pais)
